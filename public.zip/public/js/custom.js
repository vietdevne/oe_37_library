import swal from 'sweetalert';

$("#logout").click(function() {
    $.ajax({
        type: 'POST',
        url: '/logout',
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function() {
            $(location).attr('href', '/');
        }
    });
});

$("#mark-as-read").click(function() {
    var notificationsToggle = $('#dropdown-notifications').find('a[id="notiDropdown"]');
    var notificationsCountElem = notificationsToggle.find('i[data-count]');
    $.ajax({
        type: 'POST',
        url: '/user/mark_as_read',
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(data) {
            notificationsCountElem.attr('data-count', 0); // reset
            $('#notiContent').html('');
            swal({
                icon: data.status,
                buttons: false
            });
        }
    });
});

$('.likebtn').click(function() {
    var id = $(this).data("id");
    var btn = $(this);
    $.ajax({
        type: 'POST',
        url: '/book/like',
        dataType: 'json',
        data: { book_id: id },
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(data) {

            swal({
                text: data.msg,
                icon: data.status,
            });

            if (data.status == 'success') {
                btn.html(data.btn_content);

            }
        }
    });
});

var pusher = new Pusher('2dfb2e310574753bd71d', {
    encrypted: true,
    cluster: "ap1"
});
var notificationsToggle = $('#dropdown-notifications').find('a[id="notiDropdown"]');
var notificationsCountElem = notificationsToggle.find('i[data-count]');
var notificationsCount = parseInt(notificationsCountElem.data('count'));
var channel = pusher.subscribe('NotificationEvent');
channel.bind('send-message', function(data) {
    var newNotificationHtml = `
    <a class="dropdown-item bg-warning" href="#"><strong>${data.title}</strong>
      <br/>
      <span class="text-muted text">${data.content}</span>
    </a>
    `;

    $('#notiContent').prepend(newNotificationHtml);
    notificationsCount += 1;
    notificationsCountElem.attr('data-count', notificationsCount);
    console.log(notificationsCount);
});